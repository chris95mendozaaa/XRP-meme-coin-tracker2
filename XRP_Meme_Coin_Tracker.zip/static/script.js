let coins = [];

function money(n) {
  n = Number(n || 0);
  if (n >= 1e9) return "$" + (n/1e9).toFixed(2) + "B";
  if (n >= 1e6) return "$" + (n/1e6).toFixed(2) + "M";
  if (n >= 1e3) return "$" + (n/1e3).toFixed(2) + "K";
  return "$" + n.toFixed(6);
}
function num(n) { return Number(n || 0).toLocaleString(); }
function pct(n) { return (Number(n || 0) >= 0 ? "+" : "") + Number(n || 0).toFixed(2) + "%"; }

async function loadCoins() {
  document.getElementById("table").innerHTML =
    '<tr><td colspan="9">Loading live data...</td></tr>';
  try {
    const r = await fetch("/api/memes");
    const data = await r.json();
    if (!data.success) throw new Error(data.error);
    coins = data.tokens;
    document.getElementById("count").textContent = coins.length;
    document.getElementById("leader").textContent = coins[0]?.name || "—";
    document.getElementById("updated").textContent = new Date().toLocaleTimeString();
    document.getElementById("summary").textContent = data.analysis;
    render();
  } catch (e) {
    document.getElementById("table").innerHTML =
      '<tr><td colspan="9">Unable to load live data. Try Refresh Data.</td></tr>';
    document.getElementById("summary").textContent = "Data request failed: " + e.message;
  }
}

function render(list = null) {
  const search = document.getElementById("search").value.toLowerCase();
  const sort = document.getElementById("sort").value;
  let arr = (list || coins).filter(c =>
    (c.name + " " + c.symbol).toLowerCase().includes(search)
  );
  arr.sort((a,b) => Number(b[sort] || 0) - Number(a[sort] || 0));

  document.getElementById("table").innerHTML = arr.map((c,i) => `
    <tr>
      <td>${c.rank}</td>
      <td><b>${escapeHtml(c.name)}</b><small>${escapeHtml(c.symbol)}</small></td>
      <td>${money(c.price)}</td>
      <td>${money(c.marketcap)}</td>
      <td>${num(c.volume)} XRP</td>
      <td class="${Number(c.change24h)>=0?'up':'down'}">${pct(c.change24h)}</td>
      <td>${num(c.holders)}</td>
      <td>${num(c.tvl)} XRP</td>
      <td><button class="small" onclick='analyze(${JSON.stringify(c)})'>Analyze</button></td>
    </tr>`).join("");
}

function showGainers() {
  const sorted = [...coins].sort((a,b)=>Number(b.change24h)-Number(a.change24h)).slice(0,10);
  render(sorted);
}

async function analyze(c) {
  const r = await fetch("/api/analyze", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({token:c})
  });
  const data = await r.json();
  alert(data.analysis);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[m]));
}
loadCoins();
