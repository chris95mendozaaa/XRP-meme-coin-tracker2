import os
import requests
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

API_URL = "https://api.xrpl.to/v1/tokens"

def get_meme_tokens():
    params = {
        "tag": "Memes",
        "sort": "marketcap",
        "order": "desc",
        "limit": 30,
        "tags": "yes",
        "lightweight": "true"
    }
    headers = {"User-Agent": "XRP-Meme-Coin-Tracker/1.0"}
    r = requests.get(API_URL, params=params, headers=headers, timeout=15)
    r.raise_for_status()
    data = r.json()
    return data.get("tokens", [])

def ai_style_analysis(tokens):
    if not tokens:
        return "No meme-coin data is available right now."
    leaders = tokens[:5]
    best_24h = max(tokens, key=lambda x: float(x.get("pro24h") or 0))
    highest_volume = max(tokens, key=lambda x: float(x.get("vol24hxrp") or 0))
    return (
        f"Market snapshot: {len(tokens)} XRPL meme tokens were returned. "
        f"The current #1 market-cap token is {leaders[0].get('name','Unknown')}. "
        f"The strongest 24-hour percentage mover in this list is "
        f"{best_24h.get('name','Unknown')} ({float(best_24h.get('pro24h') or 0):+.2f}%). "
        f"The highest 24-hour XRP volume is {highest_volume.get('name','Unknown')}. "
        "Use market cap, volume, liquidity/TVL, holders, and price changes together rather than relying on one metric."
    )

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/memes")
def memes():
    try:
        tokens = get_meme_tokens()
        cleaned = []
        for i, t in enumerate(tokens, 1):
            cleaned.append({
                "rank": i,
                "name": t.get("name") or t.get("currency") or "Unknown",
                "symbol": t.get("currency") or "",
                "price": t.get("usd") or t.get("exch") or 0,
                "marketcap": t.get("marketcap") or 0,
                "volume": t.get("vol24hxrp") or 0,
                "change24h": t.get("pro24h") or 0,
                "change7d": t.get("pro7d") or 0,
                "holders": t.get("holders") or 0,
                "tvl": t.get("tvl") or 0,
                "traders": t.get("uniqueTraders24h") or 0,
                "issuer": t.get("issuer") or "",
                "id": t.get("md5") or t.get("slug") or ""
            })
        return jsonify({"success": True, "count": len(cleaned), "tokens": cleaned,
                        "analysis": ai_style_analysis(cleaned)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 502

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(silent=True) or {}
    token = data.get("token", {})
    name = token.get("name", "This token")
    mc = float(token.get("marketcap") or 0)
    vol = float(token.get("volume") or 0)
    holders = int(float(token.get("holders") or 0))
    change = float(token.get("change24h") or 0)

    notes = []
    if vol > 0 and mc > 0:
        turnover = vol / mc
        notes.append(f"24h volume is about {turnover*100:.1f}% of market cap.")
    if holders >= 1000:
        notes.append("It has a relatively large holder count within this dashboard.")
    elif holders:
        notes.append("Holder count is relatively small, so liquidity and concentration deserve extra attention.")
    if change > 10:
        notes.append("The token has strong positive 24h momentum.")
    elif change < -10:
        notes.append("The token has significant negative 24h momentum.")
    else:
        notes.append("The 24h price move is relatively moderate.")

    return jsonify({
        "analysis": f"AI-style research summary for {name}: " + " ".join(notes) +
        " This is market-data analysis, not financial advice."
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
