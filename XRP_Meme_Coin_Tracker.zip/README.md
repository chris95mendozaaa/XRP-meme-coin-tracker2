# XRP Meme Coin Tracker

## FRSE 101 Project

### Project Description
This project is an interactive dashboard that checks the top 30 meme tokens on the XRP Ledger. It retrieves live market information and lets users compare tokens using market capitalization, 24-hour volume, price change, holders, and TVL.

### Problem
XRP Ledger meme-coin information can be spread across different pages. A student or researcher may have difficulty quickly comparing the leading tokens.

### Intended Users
Crypto-curious students, XRP Ledger community members, and people learning how cryptocurrency dashboards work.

### Solution
The dashboard retrieves XRPL meme-token data and ranks the top 30 by market capitalization. Users can search, sort, refresh the data, view top gainers, and request a quick AI-style research summary.

### AI
AI was used during development to design the application, generate and review code, improve the user interface, and structure the research-summary feature.

### Technology Stack
- Python
- Flask
- HTML
- CSS
- JavaScript
- XRPL.to API

### Data Source
The application uses the XRPL.to API. The site requires visible attribution when its data is displayed, so the dashboard includes a "Data by xrpl.to" credit.

### Run Locally
pip install -r requirements.txt
python app.py

Then open http://127.0.0.1:5000

### Deployment
Upload this project to GitHub and deploy it as a Python web service on Render.

Build command:
pip install -r requirements.txt

Start command:
python app.py

### Important
This is an educational market-data project, not financial advice. Do not add private keys, API secrets, passwords, or access tokens to GitHub.
